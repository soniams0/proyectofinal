/* 

const HomeView = () => {
    return (
        <div
          className="bg-[url(/img1.jpg')] bg-cover bg-center h-[50vh] flex flex-col justify-center items-center text-white"
        >
          <div className="text-center mt-10">
            <h1 className="text-4xl font-bold">WELCOME TO HOTELIFY!</h1>
            <p className="mt-4 max-w-lg">
              Discover exceptional comfort, curated just for you. Experience seamless service and unforgettable stays with us. Enjoy your journey!
            </p>
          </div>
        </div>
      );
  };
  
  export default HomeView; */
