import HomeView from "@/view/homeView/homeView";

export default function Home() {
  return (
  
    <>
<HomeView />  
    </>
  );
}
