import Login from "@/view/loginView/loginView"
const page = () => {
  return (
    <>
     <Login/>
     </>
  )
}

export default page
