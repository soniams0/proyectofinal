import Register from '@/view/registerView/registerView'

const page = () => {
  return (
    <div>
      <Register/>
    </div>
  )
}

export default page
